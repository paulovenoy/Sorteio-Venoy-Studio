const WS_URL = "ws://localhost:3000";

const STATUS = {
  WIN: "youwin",
  LOSE: "youlose",
};

const ACTIONS = {
  ADMIN: "admin",
  DRAW: "draw",
  CLIENT_COUNT_UPDATE: "clientCountUpdate",
};
